create procedure doLogin(IN userId int, IN gameId int, IN ticket varchar(32), IN loginAccount varchar(55),
                         IN ip     varchar(15), IN ua varchar(100), IN channelId int, OUT error int)
  BEGIN
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET error=1;
  START TRANSACTION; 
    SET error=1;
    delete from sdk_online.ONLINE_USER where USER_ID=userId and GAME_ID=gameId;
    insert into sdk_online.ONLINE_USER (TICKET, USER_ID, LOGIN_ACCOUNT, GAME_ID, IP, UA, LOGIN_DATE, LAST_ACT)
    values (ticket, userId, loginAccount, gameId, ip, ua, now(), now());
    update USER_DYNAMIC 
    set LAST_LOGIN_DATE = now(), LOGIN_CNT = LOGIN_CNT + 1, LAST_IP = ip ,LAST_UA = ua
    where USER_ID = userId;
    IF not EXISTS(select PROMOTION_CHANNEL_ID from sdk_log.GAME_REGIST_LOG
    where USER_ID=userId and GAME_ID=gameId) THEN
			insert into sdk_log.GAME_REGIST_LOG (USER_ID, GAME_ID, PROMOTION_CHANNEL_ID, CREATED_DATE) values 
			(userId, gameId, channelId, now());
    END IF; 
    IF error = 1 THEN 
		  ROLLBACK;  
    ELSE  
      COMMIT;  
    END IF; 
end;

